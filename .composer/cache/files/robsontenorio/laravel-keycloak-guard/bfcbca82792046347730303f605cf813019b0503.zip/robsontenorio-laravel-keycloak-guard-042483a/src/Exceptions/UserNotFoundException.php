<?php

namespace KeycloakGuard\Exceptions;

class UserNotFoundException extends KeycloakGuardException
{
}
