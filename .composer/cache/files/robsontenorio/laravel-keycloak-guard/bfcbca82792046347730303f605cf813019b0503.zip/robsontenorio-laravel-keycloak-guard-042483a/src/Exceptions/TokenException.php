<?php

namespace KeycloakGuard\Exceptions;

class TokenException extends KeycloakGuardException
{
}
