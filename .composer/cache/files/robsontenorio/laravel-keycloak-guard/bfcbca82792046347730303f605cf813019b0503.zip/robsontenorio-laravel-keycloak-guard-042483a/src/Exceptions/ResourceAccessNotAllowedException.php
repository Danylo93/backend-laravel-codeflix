<?php

namespace KeycloakGuard\Exceptions;

class ResourceAccessNotAllowedException extends KeycloakGuardException
{
}
